"""Measure visible tail movement and preservation of the approved character."""

from __future__ import annotations

import json
from collections import deque
from pathlib import Path
import numpy as np
from PIL import Image

from animate_tail import BASE, DEST, PHASES, USED, make_phases


ROOT = Path(__file__).resolve().parent
BEFORE = np.asarray(Image.open(BASE).convert("RGBA"))
AFTER = np.asarray(Image.open(DEST).convert("RGBA"))


def connected_tail_pixels(character: np.ndarray, complete: np.ndarray) -> int:
    base = character[:, :, 3] > 16
    visible = complete[:, :, 3] > 16
    seen = base.copy()
    queue = deque((int(y), int(x)) for y, x in zip(*np.nonzero(base)))
    height, width = seen.shape
    while queue:
        y, x = queue.popleft()
        for ny, nx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1),
                       (y - 1, x - 1), (y - 1, x + 1), (y + 1, x - 1), (y + 1, x + 1)):
            if 0 <= ny < height and 0 <= nx < width and visible[ny, nx] and not seen[ny, nx]:
                seen[ny, nx] = True
                queue.append((ny, nx))
    added = visible & ~base
    return int((added & ~seen).sum())


def main() -> None:
    right, _ = make_phases()
    components = [np.asarray(img) for img in right]
    component_differences = {
        f"{a}-{b}": int(np.any(components[a] != components[b], axis=2).sum())
        for a in range(4) for b in range(a + 1, 4)
    }
    assert min(component_differences.values()) > 100

    report = {"ok": True, "component_pixel_differences": component_differences, "rows": []}
    failures = []
    for row, count in enumerate(USED):
        entries = []
        for col in range(count):
            y0, y1 = row * 208, (row + 1) * 208
            x0, x1 = col * 192, (col + 1) * 192
            before = BEFORE[y0:y1, x0:x1]
            after = AFTER[y0:y1, x0:x1]
            # Opaque approved character pixels must survive exactly.
            assert np.array_equal(before[before[:, :, 3] == 255], after[before[:, :, 3] == 255])
            added = int(((after[:, :, 3] > 16) & (before[:, :, 3] <= 16)).sum())
            disconnected = connected_tail_pixels(before, after)
            entry = {"column": col, "visible_new_pixels": added,
                     "disconnected_new_pixels": disconnected}
            if row < 9:
                entry["tail_phase"] = PHASES[row][col]
                if added == 0:
                    failures.append((row, col, "tail hidden"))
                if disconnected:
                    failures.append((row, col, f"{disconnected} detached pixels"))
            entries.append(entry)
        if row < 9:
            phases = PHASES[row]
            assert all(phases[i] != phases[i + 1] for i in range(count - 1))
        report["rows"].append({"row": row, "frames": entries})

    report["ok"] = not failures
    report["failures"] = failures
    (ROOT / "motion-qa.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"ok": report["ok"], "minimum_phase_difference": min(component_differences.values()),
                      "minimum_visible_tail_pixels": min(item["visible_new_pixels"]
                                                 for row in report["rows"][:9] for item in row["frames"]),
                      "failures": failures}))
    assert not failures


if __name__ == "__main__":
    main()
