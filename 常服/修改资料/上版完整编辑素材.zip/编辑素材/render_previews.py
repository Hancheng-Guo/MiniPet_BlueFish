"""Render exact-cell motion previews for the whale-tail revision."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from PIL import Image


ROOT = Path(__file__).resolve().parent
ATLAS = ROOT / "spritesheet-tail-connected.png"
FRAMES = ROOT / "frames"
PREVIEWS = ROOT / "previews"
ROWS = (
    ("idle", 6), ("running-right", 8), ("running-left", 8),
    ("waving", 4), ("jumping", 5), ("failed", 8),
    ("waiting", 6), ("running", 6), ("review", 6),
)


def save_gif(path: Path, frames: list[Image.Image], milliseconds: int) -> None:
    frames[0].save(path, save_all=True, append_images=frames[1:],
                   duration=milliseconds, loop=0, disposal=2, optimize=False)


def main() -> None:
    atlas = Image.open(ATLAS).convert("RGBA")
    PREVIEWS.mkdir(exist_ok=True)
    frame_map: dict[str, list[Image.Image]] = {}
    for row, (state, count) in enumerate(ROWS):
        folder = FRAMES / state
        folder.mkdir(parents=True, exist_ok=True)
        images = []
        for col in range(count):
            frame = atlas.crop((col * 192, row * 208, (col + 1) * 192, (row + 1) * 208))
            frame.save(folder / f"{col:02d}.png")
            images.append(frame)
        frame_map[state] = images

    looks = [atlas.crop(((idx % 8) * 192, (9 + idx // 8) * 208,
                         (idx % 8 + 1) * 192, (10 + idx // 8) * 208))
             for idx in range(16)]
    all_frames = [frame for state, _ in ROWS for frame in frame_map[state]]
    save_gif(PREVIEWS / "all-states.gif", all_frames, 140)
    save_gif(PREVIEWS / "idle-hover-idle.gif",
             frame_map["idle"] + frame_map["jumping"] + frame_map["idle"], 160)
    save_gif(PREVIEWS / "look-loop.gif", looks, 180)
    for name, frame in {
        "idle-front": frame_map["idle"][0],
        "running-right": frame_map["running-right"][2],
        "running-left": frame_map["running-left"][2],
        "hover-eating": frame_map["jumping"][2],
        "look-right": looks[4],
        "look-left": looks[12],
    }.items():
        frame.save(PREVIEWS / f"{name}.png")

    # MP4 is a broadly compatible copy of the all-state preview.
    sys.path.insert(0, str(ROOT.parent / "whale-tail-update" / "vendor"))
    import imageio_ffmpeg

    video_frames = ROOT / "video-frames"
    video_frames.mkdir(exist_ok=True)
    for idx, frame in enumerate(all_frames):
        canvas = Image.new("RGBA", frame.size, "#f3f6fc")
        canvas.alpha_composite(frame)
        canvas.convert("RGB").resize((384, 416), Image.Resampling.NEAREST).save(
            video_frames / f"{idx:03d}.png"
        )
    subprocess.run([
        imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-loglevel", "error",
        "-framerate", "7", "-i", str(video_frames / "%03d.png"),
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
        str(PREVIEWS / "all-states.mp4"),
    ], check=True)
    print(PREVIEWS)


if __name__ == "__main__":
    main()
