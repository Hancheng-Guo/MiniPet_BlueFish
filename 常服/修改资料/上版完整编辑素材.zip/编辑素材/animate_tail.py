"""Assemble ImageGen whale-tail motion behind approved character frames.

Only generated tail pixels are transformed and composited. The existing
character artwork, including idle and hover-eating poses, is preserved.
"""

from __future__ import annotations

from pathlib import Path
from PIL import Image


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "base-no-tail.png"
TAIL_STRIP = ROOT / "tail-motion-long-stalk.png"
DEST = ROOT / "spritesheet-tail-connected.png"
CELL_W, CELL_H = 192, 208
USED = (6, 8, 8, 4, 5, 8, 6, 6, 6, 8, 8)
PHASES = (
    (0, 1, 3, 2, 3, 1),                  # visible idle swish
    (0, 1, 3, 2, 0, 1, 3, 2),            # run right
    (0, 1, 3, 2, 0, 1, 3, 2),            # run left
    (0, 1, 3, 2),                        # wave
    (0, 1, 3, 2, 0),                     # eat rice, keeping the hands unchanged
    (2, 3, 2, 0, 2, 3, 2, 0),            # tired / failed
    (0, 1, 3, 2, 3, 1),                  # waiting
    (0, 1, 3, 2, 1, 0),                  # working
    (0, 1, 3, 2, 3, 1),                  # review
)


def tail_placement(row: int, col: int) -> tuple[str, int]:
    if row == 1:
        return "left", 3
    if row == 2:
        return "right", 115
    if row == 9:
        return (
            ("right", 115), ("right", 110), ("right", 100),
            ("left", 45), ("left", 8), ("left", 8),
            ("left", 8), ("left", 28),
        )[col]
    if row == 10:
        return (
            ("right", 87), ("right", 100), ("right", 115),
            ("right", 115), ("right", 115), ("right", 115),
            ("right", 115), ("right", 115),
        )[col]
    if row == 6:
        return "right", 115
    return "right", 115


def make_phases() -> tuple[list[Image.Image], list[Image.Image]]:
    strip = Image.open(TAIL_STRIP).convert("RGBA")
    width = strip.width / 4
    right = []
    for idx in range(4):
        zone = strip.crop((round(idx * width), 0, round((idx + 1) * width), strip.height))
        bbox = zone.getchannel("A").getbbox()
        assert bbox, f"missing tail phase {idx}"
        source = zone.crop(bbox)
        scaled_h = round(source.height * 76 / source.width)
        source = source.resize((76, scaled_h), Image.Resampling.LANCZOS)
        # Anchor the stalk at a fixed point; let only the distal fluke move.
        stalk = source.crop((0, 0, 9, source.height)).getchannel("A").getbbox()
        assert stalk
        root_y = (stalk[1] + stalk[3]) // 2
        canvas = Image.new("RGBA", (76, 64), (0, 0, 0, 0))
        canvas.alpha_composite(source, (0, 32 - root_y))
        right.append(canvas)
    left = [frame.transpose(Image.Transpose.FLIP_LEFT_RIGHT) for frame in right]
    return right, left


def main() -> None:
    original = Image.open(BASE).convert("RGBA")
    assert original.size == (1536, 2288)
    right, left = make_phases()
    atlas = Image.new("RGBA", original.size, (0, 0, 0, 0))
    for row, count in enumerate(USED):
        for col in range(count):
            box = (col * CELL_W, row * CELL_H, (col + 1) * CELL_W, (row + 1) * CELL_H)
            character = original.crop(box)
            bbox = character.getchannel("A").getbbox()
            assert bbox, (row, col)
            side, x = tail_placement(row, col)
            phase = PHASES[row][col] if row < 9 else 0
            tail = (left if side == "left" else right)[phase]
            y = max(81, min(129, bbox[3] - 83))
            if row in (1, 2):
                y -= 4
            composed = Image.new("RGBA", (CELL_W, CELL_H), (0, 0, 0, 0))
            composed.alpha_composite(tail, (x, y))
            composed.alpha_composite(character)
            atlas.paste(composed, box[:2])
    atlas.save(DEST, optimize=True)
    print(DEST)


if __name__ == "__main__":
    main()
